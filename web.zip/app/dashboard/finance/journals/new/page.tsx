"use client";

import JournalForm from "../../components/JournalForm";

export default function NewJournalEntry() {
  return <JournalForm />;
}
