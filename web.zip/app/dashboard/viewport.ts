// app/dashboard/viewport.ts
export const viewport = {
  width: "device-width",
  initialScale: 1,
};
