import ComingSoon from "@/components/ComingSoon";

export default function BillingSettingsPage() {
  return <ComingSoon label="Billing Settings" />;
}
