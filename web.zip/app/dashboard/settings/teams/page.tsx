import ComingSoon from "@/components/ComingSoon";

export default function TeamsSettingsPage() {
  return <ComingSoon label="Teams Settings" />;
}
