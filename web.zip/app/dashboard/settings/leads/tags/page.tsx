export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold">Tags (placeholder)</h1>
      <p className="text-sm text-slate-400 mt-2">Placeholder page until implementation.</p>
    </div>
  );
}
