// app/tenant/page.tsx
export default function TenantPage() {
  return (
    <div style={{padding:20}}>
      <h1>Tenant route is working</h1>
      <p>If you see this, /tenant is served correctly.</p>
    </div>
  );
}
