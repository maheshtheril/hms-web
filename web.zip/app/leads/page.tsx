import React from "react";
import LeadsClientWrapper from "./LeadsClientWrapper";

export const metadata = { title: "Leads" };

export default function Page() {
  return <LeadsClientWrapper />;
}
