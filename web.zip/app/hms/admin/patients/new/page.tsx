import PatientsForm from "../../PatientsForm";

export default function NewPatientPage() {
  return <PatientsForm />;
}
