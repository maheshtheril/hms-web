import ComingSoon from "@/components/ComingSoon";

export default function AllActivitiesPage() {
  return <ComingSoon label="All Activities" />;
}
