"use client";

import LeadDrawersClient from "./LeadDrawersClient";

export default function LeadDrawersBoundary() {
  return <LeadDrawersClient />;
}
