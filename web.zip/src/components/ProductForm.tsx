import React from "react";

export default function ProductForm(): JSX.Element {
  return <div>ProductForm (stub)</div>;
}
