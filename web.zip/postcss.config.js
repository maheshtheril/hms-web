// Minimal, v4-style PostCSS config
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
  },
};
